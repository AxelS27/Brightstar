<?php
echo password_hash('T270206001', PASSWORD_DEFAULT);
?>